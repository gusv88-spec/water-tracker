WEEKLY WATER TRACKER — DEPLOYABLE WEBSITE

Files:
- index.html  (main app)
- water-tracker.html (same app, alternate entry)
- manifest.webmanifest (PWA manifest)
- sw.js (service worker for offline support)
- icon-192.png / icon-512.png (PWA icons)

Quick deploy options:

1) GitHub Pages (free)
   - Create a new repo (e.g., water-tracker).
   - Upload all files in this folder to the repo root.
   - In the repo: Settings → Pages → Build and deployment → Source: "Deploy from a branch", Branch: "main" / "/root".
   - Your site will be live at: https://<your-username>.github.io/<repo-name>/
   - Open on iPhone Safari → Share → Add to Home Screen to install.

2) Netlify (free tier)
   - Visit https://app.netlify.com/ → New site from Git.
   - Connect your Git repo containing these files, or drag-and-drop this folder in "Deploys".
   - No build command required; publish directory = root.
   - Netlify gives you a public URL immediately.

3) Vercel (free tier)
   - Visit https://vercel.com/ → "New Project".
   - Import a Git repo containing these files.
   - Framework preset: "Other"; Build command: none; Output directory: "."
   - Deploy. You get a public URL.

4) Any static host
   - Upload these files to the root of your web server's public folder.
   - Ensure HTTPS is used for PWA install prompts.

Notes:
- Data is stored locally in the browser (localStorage). Use Export/Import JSON for backups.
- If IRWD's CORS blocks "Fetch latest", use another browser to fetch, export JSON, then import here.
